package com.first.recruIT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecruItApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecruItApplication.class, args);
	}

}
