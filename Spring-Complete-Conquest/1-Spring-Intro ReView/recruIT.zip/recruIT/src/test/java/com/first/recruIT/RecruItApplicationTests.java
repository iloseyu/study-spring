package com.first.recruIT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecruItApplicationTests {

	@Test
	void contextLoads() {
	}

}
